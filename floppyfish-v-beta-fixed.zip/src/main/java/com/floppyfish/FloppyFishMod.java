package com.floppyfish;
import com.floppyfish.entity.FloppyFishBobberEntity;
import com.floppyfish.item.FloppyFishItem;
import com.floppyfish.item.FloppyFishRopeItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
public class FloppyFishMod implements ModInitializer {
    public static final String MODID = "floppyfish";
    public static Item FLOPPY_FISH_ROPE;
    public static Item FLOPPY_FISH;
    public static EntityType<FloppyFishBobberEntity> FLOPPY_FISH_BOBBER;
    @Override public void onInitialize() {
        FLOPPY_FISH_ROPE = Registry.register(Registries.ITEM, new Identifier(MODID, "floppy_fish_rope"), new FloppyFishRopeItem(new FabricItemSettings().maxCount(1)));
        FLOPPY_FISH = Registry.register(Registries.ITEM, new Identifier(MODID, "floppy_fish"), new FloppyFishItem(new FabricItemSettings()));
        FLOPPY_FISH_BOBBER = Registry.register(Registries.ENTITY_TYPE, new Identifier(MODID, "floppy_fish_bobber"), EntityType.Builder.<FloppyFishBobberEntity>create(FloppyFishBobberEntity::new, SpawnGroup.MISC).setDimensions(0.25F,0.25F).maxTrackingRange(64).trackedUpdateRate(5).build());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(c->{c.add(FLOPPY_FISH_ROPE); c.add(FLOPPY_FISH);});
    }
}
