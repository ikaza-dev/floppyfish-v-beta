package com.floppyfish; import net.fabricmc.api.ClientModInitializer; public class FloppyFishClient implements ClientModInitializer { @Override public void onInitializeClient() {} }
